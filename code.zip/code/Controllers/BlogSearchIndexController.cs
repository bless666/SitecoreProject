﻿using AlexaHelix.Feature.Blog.Models;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.Linq;
using Sitecore.ContentSearch.Linq.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;

namespace AlexaHelix.Feature.Blog.Controllers
{
    public class BlogSearchIndexController : Controller
    {
        // GET: BlogSearchIndex
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult DoSearch(string searchText)
        {
            var myResults = new SearchResults
            {
                Results = new List<SearchResult>()
            };
            var searchIndex = ContentSearchManager.GetIndex("sitecore_web_index"); 
            var searchPredicate = GetSearchPredicate(searchText); 
            using (var searchContext = searchIndex.CreateSearchContext()) 
            {
                var searchResults = searchContext.GetQueryable<SearchModel>()
                    .Where(x => x.TemplateName == "Article" && (x.Title.Contains(searchText) || x.Type.Contains(searchText) || x.Description.Contains(searchText) || x.LongDescription.Contains(searchText) || x.Tags.Contains(searchText)));   //LINQ query

                var fullResults = searchResults.GetResults();

                foreach (var hit in fullResults.Hits)
                {
                    var imageId = hit.Document.ItemId;
                    var imgTag = "";
                    var imagecontext = Sitecore.Context.Database.GetItem(imageId);
                    var redirectName = imagecontext.Name;
                    Sitecore.Data.Fields.ImageField imageField = imagecontext.Fields["Image"];

                    if (imageField != null && imageField.MediaItem != null)
                    {
                        Sitecore.Data.Items.MediaItem image = new Sitecore.Data.Items.MediaItem(imageField.MediaItem);

                        string src = Sitecore.StringUtil.EnsurePrefix('/',

                        Sitecore.Resources.Media.MediaManager.GetMediaUrl(image));

                        imgTag = String.Format(@"<img src=""{0}"" alt=""{1}"" />", src, image.Alt);
                    }

                    myResults.Results.Add(new SearchResult
                    {
                        Type = hit.Document.Type,
                        Title = hit.Document.Title,
                        PostDate = hit.Document.PostDate.ToString("MMM d, yyyy"),
                        LongDescription = hit.Document.LongDescription,
                        Description = hit.Document.Description,
                        ReadOnImage = hit.Document.ReadOnImage,
                        Image = imgTag,
                        Tags = hit.Document.Tags,
                        RedirectNmae = redirectName
                    });
                }
                return new JsonResult { JsonRequestBehavior = JsonRequestBehavior.AllowGet, Data = myResults };
            }
        }

        public static Expression<Func<SearchModel, bool>> GetSearchPredicate(string searchText)
        {
            var predicate = PredicateBuilder.True<SearchModel>();
            predicate = predicate.Or(x => x.LongDescription.Contains(searchText));
            predicate = predicate.Or(x => x.Description.Contains(searchText));
            predicate = predicate.Or(x => x.Type.Contains(searchText));
            predicate = predicate.Or(x => x.Title.Contains(searchText));
            predicate = predicate.Or(x => x.Tags.Contains(searchText));
            return predicate;
        }
    }
}