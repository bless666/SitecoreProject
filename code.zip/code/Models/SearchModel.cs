﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Sitecore.ContentSearch;
using Sitecore.ContentSearch.SearchTypes;
using System.Collections.Generic;

namespace AlexaHelix.Feature.Blog.Models
{
    public class SearchModel : SearchResultItem
    {
        [IndexField("title_t")]
        public virtual string Title { get; set; }
        [IndexField("type_t")]
        public virtual string Type { get; set; } 
        [IndexField("postdate_t")]
        public virtual DateTime PostDate { get; set; }
        [IndexField("image")]
        public virtual string Image { get; set; }
        [IndexField("readonimage")]
        public virtual string ReadOnImage { get; set; }
        [IndexField("description_t")]
        public virtual string Description { get; set; }
        [IndexField("longdescription_t")]
        public virtual string LongDescription { get; set; }
        [IndexField("tags_t")]
        public virtual string Tags { get; set; }
    }
    public class SearchResult
    {
        public string Title { get; set; }
        public string Type { get; set; }
        public string PostDate { get; set; }
        public string Image { get; set; }
        public string ReadOnImage { get; set; }
        public string Description { get; set; }
        public string LongDescription { get; set; }
        public string Tags { get; set; }
        public string RedirectNmae { get; set; }
    }

    public class SearchResults
    {
        public List<SearchResult> Results { get; set; }
    }
}